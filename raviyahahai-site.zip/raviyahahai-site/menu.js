(function () {
  var header = document.querySelector('.top');
  var btn = document.querySelector('.menu-btn');
  if (!header || !btn) return;

  function setOpen(open) {
    header.classList.toggle('open', open);
    document.documentElement.classList.toggle('menu-open', open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  }

  btn.addEventListener('click', function () {
    setOpen(!header.classList.contains('open'));
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && header.classList.contains('open')) {
      setOpen(false);
      btn.focus();
    }
  });
  Array.prototype.forEach.call(header.querySelectorAll('nav a'), function (a) {
    a.addEventListener('click', function () { setOpen(false); });
  });
  window.matchMedia('(min-width: 701px)').addEventListener('change', function (e) {
    if (e.matches) setOpen(false);
  });
})();
