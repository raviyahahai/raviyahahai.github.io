(function () {
  var dlg = document.getElementById('lightbox');
  var pieces = Array.prototype.slice.call(document.querySelectorAll('.piece'));
  if (!dlg || typeof dlg.showModal !== 'function' || !pieces.length) return;

  var img = dlg.querySelector('img');
  var cap = dlg.querySelector('figcaption');
  var current = 0;

  function show(n) {
    current = (n + pieces.length) % pieces.length;
    var p = pieces[current];
    var src = p.querySelector('img');
    img.src = src.currentSrc || src.src;
    img.alt = src.alt;
    var fc = p.querySelector('figcaption');
    cap.textContent = fc ? fc.textContent : '';
    cap.hidden = !fc;
  }

  pieces.forEach(function (p, n) {
    var im = p.querySelector('img');
    var fc0 = p.querySelector('figcaption');
    var label = fc0 ? fc0.textContent : (im.alt || 'illustration');
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'zoom';
    btn.setAttribute('aria-label', 'View larger: ' + label);
    im.parentNode.replaceChild(btn, im);
    btn.appendChild(im);
    btn.addEventListener('click', function () {
      show(n);
      dlg.showModal();
      document.documentElement.classList.add('lb-open');
    });
  });

  var multiple = pieces.length > 1;
  dlg.querySelector('.lb-prev').hidden = !multiple;
  dlg.querySelector('.lb-next').hidden = !multiple;

  dlg.querySelector('.lb-close').addEventListener('click', function () { dlg.close(); });
  dlg.querySelector('.lb-prev').addEventListener('click', function () { show(current - 1); });
  dlg.querySelector('.lb-next').addEventListener('click', function () { show(current + 1); });
  dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
  dlg.addEventListener('keydown', function (e) {
    if (!multiple) return;
    if (e.key === 'ArrowLeft') show(current - 1);
    if (e.key === 'ArrowRight') show(current + 1);
  });
  dlg.addEventListener('close', function () {
    document.documentElement.classList.remove('lb-open');
  });
})();
