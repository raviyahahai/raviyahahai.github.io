(function () {
  var form = document.getElementById('contact-form');
  if (!form) return;

  var email = document.getElementById('email');
  var message = document.getElementById('message');
  var statusEl = document.getElementById('form-status');
  var btn = document.getElementById('send-btn');
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function setError(input, text) {
    document.getElementById(input.id + '-error').textContent = text || '';
    input.setAttribute('aria-invalid', text ? 'true' : 'false');
  }

  function setStatus(text) { statusEl.textContent = text || ''; }

  function validate() {
    var firstBad = null;
    setStatus('');

    var e = email.value.trim();
    if (!e) {
      setError(email, 'Please fill in your email.');
      firstBad = firstBad || email;
    } else if (!EMAIL_RE.test(e)) {
      setError(email, 'Please enter a valid email address.');
      firstBad = firstBad || email;
    } else {
      setError(email, '');
    }

    if (!message.value.trim()) {
      setError(message, 'Please write a message.');
      firstBad = firstBad || message;
    } else {
      setError(message, '');
    }

    if (firstBad) firstBad.focus();
    return !firstBad;
  }

  email.addEventListener('input', function () { if (email.value.trim()) setError(email, ''); });
  message.addEventListener('input', function () { if (message.value.trim()) setError(message, ''); });

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    if (!validate()) return;

    var key = form.getAttribute('data-access-key') || '';
    if (!key || key === 'YOUR_ACCESS_KEY') {
      setStatus('Sorry, the contact form is not set up yet.');
      return;
    }

    var first = form.elements.first_name.value.trim();
    var last = form.elements.last_name.value.trim();
    var payload = {
      access_key: key,
      subject: 'New message from your portfolio website',
      name: (first + ' ' + last).trim() || 'Website visitor',
      email: email.value.trim(),
      message: message.value.trim(),
      botcheck: form.elements.botcheck.checked
    };

    btn.disabled = true;
    setStatus('Sending...');

    fetch('https://api.web3forms.com/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (res && res.success) {
          form.reset();
          setStatus('Thanks for submitting!');
        } else {
          setStatus('Something went wrong. Please try again in a moment.');
        }
      })
      .catch(function () {
        setStatus('Something went wrong. Please check your connection and try again.');
      })
      .then(function () { btn.disabled = false; });
  });
})();
